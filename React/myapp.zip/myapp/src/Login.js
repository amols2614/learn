/* eslint-disable no-unused-vars */
/* eslint-disable jsx-a11y/anchor-is-valid */
import React, { Component } from 'react';
import axios from 'axios';

export default class Login extends Component {

  onFormSubmit = (e) => {
    const url = 'https://localhost:44322/Login/Check';
    const form = document.getElementById('LoginForm');
    const formData = new FormData(form);

    axios({
      method: "post",
      url,
      data: formData,
      //headers: { "Content-Type": "multipart/form-data" },
    })
      .then(function (response) {
        //handle success
        console.log(response);
      })
      .catch(function (response) {
        //handle error
        console.log(response);
      });
    console.log(e);
    e.preventDefault();
  }

  render() {
    return (

      <form id="LoginForm" onSubmit={this.onFormSubmit} >
        <h3>Sign In</h3>

        <div className="form-group">
          <label>User Name</label>
          <input type="text" name="username" className="form-control" placeholder="User Name" />
        </div>

        <div className="form-group">
          <label>Password</label>
          <input type="password" name="password" className="form-control" placeholder="Enter password" />
        </div>

        <div className="form-group">
          <div className="custom-control custom-checkbox">
            <input type="checkbox" className="custom-control-input" id="customCheck1" />
            <label className="custom-control-label" htmlFor="customCheck1">Remember me</label>
          </div>
        </div>

        <button type="submit" className="btn btn-primary btn-block">Submit</button>
        <p className="forgot-password text-right">
          Forgot <a href="#">password?</a>
        </p>
      </form>
    );
  }
}
