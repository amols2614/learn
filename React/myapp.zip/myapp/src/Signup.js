import React, { Component } from "react";
// eslint-disable-next-line no-unused-vars
import { Container, Row, Col } from 'reactstrap';

export default class SignUp extends Component {
    render() {
        return (
            <div>
                <h3>React SignUp Component</h3>
            </div>
        );
    }
}